package com.gov.usa.ssn.endpoints;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import gov.usa.ssn.types.IndvDetailRequest;
import gov.usa.ssn.types.IndvDetailResponse;
import gov.usa.ssn.types.IndvDetailType;

@Endpoint
public class FederalSsnValidator {

	@ResponsePayload
	public IndvDetailResponse validateSsn(@RequestPayload IndvDetailRequest request) {

		// capturing data from request
		String dob = request.getDob();
		String ssn = request.getSsn();

		// TODO: Validate dob and ssn with DB

		// setting data in binding object
		IndvDetailType type = new IndvDetailType();
		type.setFirstName("John");
		type.setLastName("Peter");
		type.setSsn(ssn);
		type.setDob(dob);

		// adding binding obj to response object
		IndvDetailResponse response = new IndvDetailResponse();
		response.setIndvDetail(type);

		// returing response
		return response;

	}

}
