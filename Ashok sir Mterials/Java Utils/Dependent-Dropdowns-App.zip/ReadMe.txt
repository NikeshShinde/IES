Uploaded Dependent dropdowns (Country State City) Appliction in below link 

Step1 : Execute the Script provided in Counties-States-Cities.sql file 

Step2 : Import the war will into your IDE 
		(In Eclipse top Menu -> File -> Import -> Select War file -> Choose the War -> Click on Finish )

Step3 : Change database details in oracle.cfg.xml in the project 

Step4 : Run the appplication using Server

